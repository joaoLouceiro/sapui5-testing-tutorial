sap.ui.define([
	"./model/models",
	"./model/formatter"
], function() {
	"use strict";
});
